# 使用sm2+sm3对使用数据就行加解密


### 在axios封装请求中使用
#### 数据加密流程
- 项目里面加密的流程：，前端请求一个获取后端公钥的接口，使用后端公钥对数据加密后发送给后端
- 项目里面解密的流程：，前端把前端公钥发给后端，后端使用该公钥对数据加密返回给前端，前端再使用键匙对的私钥对数据解密
- 签名加密流程：
上一步前端把公钥发送给后端的同时，会获得一个验签的字符串值(实际上返回的就是当前登录用户的用户名)，通过前端私钥对这个字符串进行签名加密放到请求头中发送给后端

```ts
import { useCrypto } from '@basic-platform-ui/utils'


const { getSign, encryptParams, getSm2DataByEndKey } = useCrypto(requestPublicKeyApi, postFrontKeyApi, { publicKey: endKeys.publicKey, privateKey: endKeys.privateKey })


```


### 测试加密算法
:::demo 
Crypto/index
:::

## API

### useCrypto参数

| Name                   | Description                                               |
| ---------------------- | --------------------------------------------------------- |
| requestPublicKeyApi    | 获取后端公钥的接口 | 
| postFrontKeyApi        | 发送前端私钥的接口  |
| options                |   额外参数（不通过接口获取后端公钥时使用），见下面描述|

### options
| Name    | Description   |
| ------- | ---------------| 
| publicKey    | 后端测试公钥 | 
| privateKey    | 后端测试私钥 | 
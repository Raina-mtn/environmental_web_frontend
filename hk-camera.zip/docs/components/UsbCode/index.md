# 读取U盾唯一标识


### 基础用法
直接引用，点击读取可以拿到U盾的唯一标识
:::demo 
UsbCode/index
:::

### 二次鉴权使用
用在系统中重要操作需要再次鉴别的模块，传参为二次鉴别的接口
:::demo 
RecheckPass/index
:::


### UsbCode Attributes

---

### 1、配置参数（Attributes）继承 el-button Attributes

https://element-plus.gitee.io/zh-CN/component/button.html#button-attributes
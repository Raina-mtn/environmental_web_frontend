# 基础用法
::: tip
通过属性透传将 ProTable 组件属性全部透传到 el-table 上，所以我们支持 el-table 的所有 Props 属性
[el-table属性文档](https://element-plus.gitee.io/zh-CN/component/table.html#%E5%9F%BA%E7%A1%80%E8%A1%A8%E6%A0%BC)
:::

- 通过配置columns里对应字段的search属性可以配置搜索条件；
- 默认新增按钮在searchForm的同一行显示，可以在toolButtonInline插槽内显示自定义按钮；
- 如果要在搜索条件和表格中间自定义按钮，在toolButton插槽内配置自定义内容(需设置toolButton为true)
:::demo
ProTable/index
:::

## 配置searchCol设置表单项
- 配置响应式对象searchCol，可以自适应配置一行显示几个表单项; xs: <768px； sm：768-998；md： 998-1220；lg： 1220-1980；xl：>1980
::: tip
使用grid布局配置头部表单项，实际gird的列数是，每个表单项是一列，搜索重置按钮占一列， 行内新增功能按钮为一列（已自动计算，无需算入配置列中）。例如出去行内新增按钮，表单项+搜索重置按钮为4项，则配置searchCol为4
:::

:::demo
ProTable/searchCol
:::

## 配置数据主动从接口请求
配置request-api可以直接从接口拉取数据，默认展示的数据是取接口的list字段;
:::demo
ProTable/requestApi
:::


## 配置表单项为枚举
- 配置enum作为下拉框的下拉选项（可以为接口请求函数（格式为：{data: [{lable: 'xx', value: 'xx'}]}），也可以为枚举数据），同时可以格式化表格单元数据；
- 设置isFilterEnum为false时，enum只作为下拉选项，不参与格式化表格单元
:::demo
ProTable/enumSetting
:::

## 配置请求参数
- 可以通过配置fetchSetting设置请求接口的page参数，或者展示数据的字段，默认列表:list, 总页数：totalCount，页数：pageIndex，页码：pageSize;
- 设置initParam配置初始化请求参数
:::demo
ProTable/fieldSetting
:::

# ProTable API
## ProTable  配置

| 属性名 | 说明                             | 类型                 | 默认值                             |
| -------| -------------------------------- | --------------------- | -------------------------------- |
| columns | 渲染搜索表单与表格列 | 参考下面 `columnsProps` 表. | [] |
| data | 静态 tableData 数据支持分页），若存在则不会使用 requestApi 返回的 data | Array | - |
| requestApi | 获取表格数据的请求 API | Function | - |
| requestAuto | 表格初始化时是否自动执行请求 API | Boolean | true |
| requestError | 表格 API 请求错误监听 | Function | - |
| dataCallback | 后台返回数据的回调函数，可对后台返回数据进行处理 | Function | - |
| pagination | 是否显示分页组件：pagination 为 false 后台返回数据应该没有分页信息 和 list 字段，data 就是 list 数据 | Boolean | true |
| initParam | 表格请求的初始化参数，该值变化会重新请求表格数据 | Object | {} |
| toolButton | 是否显示表格功能按钮，支持（ `["refresh"/"setting"/"search"]`  | Boolean/Array | false |
| toolButtonInline | 是否在搜索条件那一列显示功能按钮  | Boolean | true |
| rowKey | 当表格数据多选时，所指定的 id | String | `id` |
| searchCol | 表格搜索项每列占比配置 | Number/Object | `{ xs: 1, sm: 2, md: 2, lg: 3, xl: 4 }` |
| fetchSetting  | 表格请求接口后分页及list，total数据配置 | Object | `{ listField: 'list', totalField: 'totalCount', pageField: 'pageIndex', sizeField: 'pageSize' }` |
| showCollapse  | 表单过多时，是否展示展开合并按钮 | Boolean | false |


## columnsProps 配置
::: tip
使用 v-bind="column" 通过属性透传将每一项 column 属性全部透传到 el-table-column 上，所以我们支持 el-table-column 的所有 Props 属性。在此基础上，还扩展了以下 Props：
:::

| 属性名 | 说明                             | 类型                 | 默认值                             |
| -------| -------------------------------- | --------------------- | -------------------------------- |
| type | 对应列的类型（`"index"/"selection"/"radio"/"expand"/"sort"`） | String | - |
| tag | 当前单元格值是否为标签展示，可通过 enum 数据中 tagType 字段指定 tag 类型 | Boolean | false |
| isShow | 当前列是否显示在表格内（只对 prop 列生效） | Boolean | true |
| search | 搜索项配置 | 参考`SearchProps`表 | —— |
| enum | 字典，可格式化单元格内容，还可以作为搜索框的下拉选项（字典可以为 API 请求函数，内部会自动执行） | `Array/Function` | —— |
| isFilterEnum | 当前单元格值是否根据 enum 格式化（例如 enum 只作为搜索项数据，不参与内容格式化） | Boolean | true |
| fieldNames | 指定 label && value && children 的 key 值 | Object | - |
| headerRender | 自定义表头内容渲染（tsx 语法、h 语法） | Function | - |
| render | 自定义单元格内容渲染（tsx 语法、h 语法） | Function | - |
| _children | 多级表头 | ColumnProps | - |


## SearchProps 配置
::: tip
使用 v-bind="column.search.props“ 通过属性透传将 search.props 属性全部透传到每一项搜索组件上，所以我们支持 input、select、tree-select、date-packer、time-picker、time-select、switch 大部分属性，并在其基础上还扩展了以下 Props：
:::
| 属性名 | 说明                             | 类型                 | 默认值                             |
| -------| -------------------------------- | --------------------- | -------------------------------- |
| el |当前项搜索框的类型，支持：input、input-number、select、select-v2、tree-select、cascader、date-picker、time-picker、time-select、switch、slider | String | - |
| label | 当搜索项 label，如果不指定默认取 column 的 label | String | - |
| props | 根据 element plus 官方文档来传递，该属性所有值会透传到组件 | Object | - |
| key | 当搜索项 key 不为 prop 属性时，可通过 key 指定 | String | —— |
| tooltip | 搜索提示 | String | —— |
| order | 搜索项排序（从小到大） | Number | true |
| span | 搜索项所占用的列数，默认为 1 列 | Number | 1 |
| offset | 搜索字段左侧偏移列数 | Number | - |
| defaultValue |搜索项默认值（该值重置时会重置回初始值） | Any | - |
| render | 自定义搜索内容渲染（tsx 语法、h 语法） | Function | - |



## ProTable 事件
| 事件名 | 说明                             | 类型                 | 类型                 |
| -------| -------------------------------- | --------------------| -------|
| search | 点击搜索按钮时触发的事件 | Function| -|
| reset | 点击重置按钮时触发的事件 | Function| -|
| create | 点击新增按钮时触发的事件 | Function| -|
| dargSort | 表格拖拽排序成功后触发 | Function| `{ newIndex, oldIndex }` |


## ProTable 方法
| 方法名 | 描述                             |   
| -------| -------------------------------- |  
| element | el-table 实例，可以通过proTable.value.element.***()来调用 el-table 的所有方法 |  
| tableData | 当前页面所展示的数据 |  
| radio | 当前表格单选值（指定 type 为 "radio" 时可取到） |  
| pageable | 当前表格的分页数据 |  
| searchParam | 所有的搜索参数，不包含分页 |  
| searchInitParam | 所有的搜索初始化默认的参数 |  
| getTableList | 获取、刷新表格数据的方法（携带所有参数） |  
| search | 表格查询方法，相当于点击搜索按钮 |  
| reset | 重置表格查询参数，相当于点击重置按钮 |  
| handleSizeChange | 表格每页条数改变触发的事件 |  
| handleCurrentChange | 表格当前页改变触发的事件 |  
| clearSelection | 清空表格所选择的数据，除此方法之外还可使用 proTable.value.element.clearSelection() |  
| enumMap | 当前表格使用的所有字典数据（Map 数据结构） |  
| isSelected | 表格是否选中数据 |  
| selectedList | 表格选中的数据列表 |  
| selectedListIds | 表格选中的数据列表的 id |  


## ProTable 插槽
| 方法名 | 描述                             |   
| -------| -------------------------------- |  
| — | 默认插槽，支持直接在 ProTable 中写 el-table-column 标签 |  
| tableHeader | 自定义表格头部左侧区域的插槽，一般情况该区域放操作按钮 |  
| toolButton |自定义表格头部左右侧侧功能区域的插槽 |  
| toolButtonInline | 自定义搜索头部右侧功能区域的插槽 |  
| append | 所有的搜索参数，不包含分页 |  
| empty | 所有的搜索初始化默认的参数 |  
| pagination | 获取、刷新表格数据的方法（携带所有参数） |  
| column.prop | 表格查询方法，相当于点击搜索按钮 |  
| column.prop + "Header" | 重置表格查询参数，相当于点击重置按钮 | 
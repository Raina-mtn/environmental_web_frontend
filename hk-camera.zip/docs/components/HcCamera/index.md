# 基础用法

::: tip
[海康插件 v3.0.0](http://www.baidu.com)
:::

- 安装 \public\hclib\v3.0\codebase\WebComponentsKit.exe；
- 支持浏览器 360 极速浏览器 版本：21.0.1216.0 内核：95.0.438.69、360 安全浏览器 版本：15.0.1321.0 内核：114.0.5735.289；

## CameraByCtrl 组件

- 播放海康视频组件
  ::: tip
  这个组件主要通过 HcCameraController 和 cameraData 控制，复杂逻辑的处理通过 HcCameraController 控制 ;
  :::

### 直接播放视频

::: demo
HcCamera/CameraByCtrl-demo1
:::

### 控制播放视频

::: demo
HcCamera/CameraByCtrl-demo2
:::

### 控制回放视频

::: demo
HcCamera/CameraByCtrl-demo3
:::

### 列表播放视频

::: demo
HcCamera/CameraByCtrl-demo4
:::

## CameraDialog 组件

- 播放海康视频弹框组件
  ::: tip
  这个组件主要是简单进行弹框播放，没有复杂的控制，直接播放视频;
  :::

:::demo
HcCamera/CameraDialog
:::

## 实例类配置

### Camera

具体调用先去 `packages\components\HcCamera\cameraController\Camera.ts`中看看

- 获取实例 `hcCameraController?.choosedCamrea`

| 方法名           | 描述               |
| ---------------- | ------------------ |
| setIWndIndex     | 设置当前选中的窗口 |
| startRealPlay    | 开始播放           |
| stopPlay         | 停止播放           |
| stopPlayAndClear | 停止播放并清空     |
| startOrEndRecord | 开始或结束录音     |
| startOrEndPlay   | 开始或结束播放     |
| capturePicture   | 抓图               |
| goPreset         | 前往预置位         |
| PTZControl       | 云台控制           |

### HcCameraController

具体调用先去 `packages\components\HcCamera\cameraController\HcCameraController.ts`中看看

demo2 中一样实例化 HcCameraController，后进行调用 `hcCameraController.getPluginCfg()`

| 方法名               | 描述                                |
| -------------------- | ----------------------------------- |
| initPlugin           | 初始化插件                          |
| getCameraByEquipment | 获取某个设备下面的所有摄像头        |
| resize               | 设置插件的大小                      |
| changeWndNum         | 设置插件窗口分割                    |
| setWnd               | 设置插件窗口分割，同时修改 pageSize |
| getPluginCfg         | 获取插件配置                        |
| openPluginDir        | 打开选择框                          |
| setPluginCfg         | 设置插件配置                        |
| stopOrStartAllPlay   | 开启所有播放                        |
| enableDraw           | 开启多边形绘制                      |
| disableDraw          | 关闭多边形绘制                      |
| AddSnapPolygon       | 开始多边形绘制                      |
| I_GetSnapPolygonInfo | 获取绘制信息                        |
| I_ClearSnapInfo      | 清空绘制信息                        |
| clear                | 清空所有                            |

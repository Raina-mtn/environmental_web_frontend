export default class HcPluginController {
  ele = null;
  g_iWndIndex = 0;

  constructor({ ele }) {
    if (ele) {
      this.ele = ele;
    }
  }

  // 初始化插件参数及插入插件
  initPlugin({ iframeId }) {
    return new Promise(async (resolve, reject) => {
      this.iframeId = iframeId;

      WebVideoCtrl.I_InitPlugin("100%", "100%", {
        bWndFull: true, //是否支持单窗口双击全屏，默认支持 true:支持 false:不支持
        // iPackageType: 2,    //2:PS 11:MP4
        iWndowType: 1,
        bNoPlugin: false,
        cbSelWnd: (xmlDoc) => {
          this.g_iWndIndex = parseInt(
            $(xmlDoc).find("SelectWnd").eq(0).text(),
            10
          );
          var szInfo = "当前选择的窗口编号：" + this.g_iWndIndex;
          console.log(szInfo);
          console.log(this.iframeId);
          window.parent.postMessage(
            {
              contentType: "g_iWndIndex",
              params: { g_iWndIndex: this.g_iWndIndex },
              iframeId: this.iframeId,
            },
            "*"
          );
        },
        cbInitPluginComplete: () => {
          let irat = WebVideoCtrl.I_InsertOBJECTPlugin(this.ele);
          if (irat == 0) {
            console.log("插入成功", this.ele);
            resolve();
          } else {
            reject();
          }
        },
      });
    });
  }

  resize = ({ width, height, left = 0, top = 0 }) => {
    if (!width) {
      width = $("body").width();
    }
    if (!height) {
      height = $("body").height();
    }
    // return WebVideoCtrl.I_Resize(width, height, left, top)
  };

  // 插入到dom原生
  insetElement() {
    return new Promise(async (resolve, reject) => {
      try {
        await WebVideoCtrl.I_InsertOBJECTPlugin(this.ele);
        resolve("插入成功");
      } catch (error) {
        console.log("插入失败", this.ele);
        reject("插入失败");
        alert(
          "插件初始化失败，请确认是否已安装插件；如果未安装，请双击开发包目录里的HCWebSDKPlugin.exe安装！"
        );
      }
    });
  }

  // 窗口分割数
  async changeWndNum(iType) {
    iType = parseInt(iType, 10);
    return WebVideoCtrl.I_ChangeWndNum(iType);
  }

  // 登录设备
  async login(params) {
    console.log("login>>>>>>>>>>>>.", "I_Login");
    const { ip, port, username, password } = params;
    return new Promise((resolve, reject) => {
      WebVideoCtrl.I_Login(ip, 1, port, username, password, {
        success: (xmlDoc) => {
          setTimeout(() => {
            // 登录后延迟下，不然后续操作失败
            console.log(ip, "登录成功");
            resolve();
          }, 1000);
        },
        error: (status, xmlDoc) => {
          console.log("status", status, xmlDoc);
          // if (2001 === oError.errorCode) {
          //     console.log(ip, '已登录过')
          //     resolve()
          // } else {
          //     console.log(ip, '登录异常')
          //     reject('登录失败！')
          // }
        },
      });
    });
  }

  async GetDigitalChannelInfo(params) {
    return new Promise((resolve, reject) => {
      WebVideoCtrl.I_GetDigitalChannelInfo(params.ip, {
        success: function (xmlDoc) {
          let oSel = [];
          var oChannels = $(xmlDoc).find("InputProxyChannelStatus");
          $.each(oChannels, function (i) {
            var id = $(this).find("id").eq(0).text(),
              name = $(this).find("name").eq(0).text(),
              online = $(this).find("online").eq(0).text();
            if ("false" == online) {
              // 过滤禁用的数字通道
              return true;
            }
            if ("" == name) {
              name = "IPCamera " + (i < 9 ? "0" + (i + 1) : i + 1);
            }
            oSel.push(id);
          });
          resolve(oSel);
        },
        error: function (oError) {
          resolve([]);
        },
      });
    });
  }

  // 开始播放
  I_StartRealPlay = async ({
    ip,
    iWndIndex,
    iStreamType,
    iChannelID,
    bZeroChannel,
  }) =>
    WebVideoCtrl.I_StartRealPlay(ip, {
      iWndIndex,
      iStreamType,
      iChannelID,
      bZeroChannel,
    });

  // 获取播放状态
  I_GetWindowStatus = async ({ iWndIndex }) =>
    WebVideoCtrl.I_GetWindowStatus(iWndIndex);

  // 停止
  I_Stop = async ({ iWndIndex }) => WebVideoCtrl.I_Stop({ iWndIndex });

  // 获取插件参数
  I_GetLocalCfg = () => {
    return new Promise((resolve, reject) => {
      let xmlDoc = WebVideoCtrl.I_GetLocalCfg();
      let params = {};
      params["BuffNumberType"] = $(xmlDoc).find("BuffNumberType").eq(0).text();
      params["PlayWndType"] = $(xmlDoc).find("PlayWndType").eq(0).text();
      params["IVSMode"] = $(xmlDoc).find("IVSMode").eq(0).text();
      params["CaptureFileFormat"] = $(xmlDoc)
        .find("CaptureFileFormat")
        .eq(0)
        .text();
      params["PackgeSize"] = $(xmlDoc).find("PackgeSize").eq(0).text();
      params["RecordPath"] = $(xmlDoc).find("RecordPath").eq(0).text();
      params["DownloadPath"] = $(xmlDoc).find("DownloadPath").eq(0).text();
      params["CapturePath"] = $(xmlDoc).find("CapturePath").eq(0).text();
      params["PlaybackPicPath"] = $(xmlDoc)
        .find("PlaybackPicPath")
        .eq(0)
        .text();
      params["DeviceCapturePath"] = $(xmlDoc)
        .find("DeviceCapturePath")
        .eq(0)
        .text();
      params["PlaybackFilePath"] = $(xmlDoc)
        .find("PlaybackFilePath")
        .eq(0)
        .text();
      params["ProtocolType"] = $(xmlDoc).find("ProtocolType").eq(0).text();
      resolve(params);
    });
  };

  // 设置本地参数
  I_SetLocalCfg = async (params) => {
    const arrXml = [];
    for (const [key, value] of Object.entries(params)) {
      arrXml.push(`<${key}>${value}</${key}>`);
    }
    WebVideoCtrl.I_SetLocalCfg(
      ["<LocalConfigInfo>", ...arrXml, "</LocalConfigInfo>"].join("")
    );
  };

  // 打开文件夹 iType 0：文件夹  1：文件
  I_OpenFileDlg = async (params) => {
    return new Promise((resolve, reject) => {
      const { iType } = params;
      const res = WebVideoCtrl.I_OpenFileDlg(iType);
      resolve(res);
    });
  };

  // 开始录像
  startRecord = async () => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 开始录像: ";
      try {
        const oWndInfo = WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        const szFileName = `${new Date().getTime()}`;
        WebVideoCtrl.I_StartRecord(szFileName, {
          bDateDir: true,
          success: () => {
            szInfo = szInfo + "成功";
            resolve(szInfo);
          },
          error: (error) => {
            throw new Error(error);
          },
        });
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 停止
  endRecord = async () => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 停止录像: ";
      try {
        const oWndInfo = WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        WebVideoCtrl.I_StopRecord();
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        resolve(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 抓图
  I_CapturePic = async ({ filename, options }) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 抓图: ";
      try {
        const oWndInfo = await WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        const irat = WebVideoCtrl.I_CapturePic(filename, options);
        if (irat == -1) {
          throw new Error("抓图失败");
        }
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 抓图
  I_PTZControl = async ({ iPTZIndex, bStop, options }) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin I_PTZControl :";
      try {
        const oWndInfo = await WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          reject(szInfo);
        }
        WebVideoCtrl.I_PTZControl(iPTZIndex, bStop, options);
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 抓图
  I_GoPreset = async ({ iPresetID, options }) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = `plugin I_GoPreset : ${iPresetID}`;
      try {
        const oWndInfo = await WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        WebVideoCtrl.I_GoPreset(iPresetID, options);
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 抓图
  I_SetPreset = async ({ iPresetID, options }) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin I_SetPreset :";
      try {
        const oWndInfo = await WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        WebVideoCtrl.I_SetPreset(iPresetID, options);
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 启用多边形绘制
  I_SetPlayModeType = async () => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin I_SetPlayModeType :";
      try {
        const oWndInfo = await WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        const irat = WebVideoCtrl.I_SetPlayModeType(6);
        if (irat == -1) {
          throw new Error("启用多边形绘制 失败");
        }
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 设置绘图模式
  I_SetSnapDrawMode = async () => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin I_SetPlayModeType :";
      try {
        const oWndInfo = await WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        const irat = WebVideoCtrl.I_SetSnapDrawMode(0, -1);

        if (irat == -1) {
          throw new Error("关闭多边形绘制 失败");
        }
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  AddSnapPolygon = async (params) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin AddSnapPolygon: ";
      try {
        const oWndInfo = WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }

        const { szId, szName } = params;
        if (
          [undefined, null].includes(szId) ||
          [undefined, null].includes(szName)
        ) {
          szInfo = szInfo + "szId或szName不存在!";
          return reject(szInfo);
        }
        let setInfo = "<?xml version='1.0' encoding='utf-8'?>";
        setInfo += "<SnapPolygonList>";
        setInfo += "<SnapPolygon>";
        setInfo += "<id>" + szId + "</id>"; // [1, 32]
        setInfo += "<polygonType>1</polygonType>";
        setInfo += "<PointNumMax>17</PointNumMax>"; // [MinClosed, 17]
        setInfo += "<MinClosed>4</MinClosed>"; // [4, 17]
        setInfo += "<tips>#" + szId + "#" + szName + "</tips>";
        setInfo += "<isClosed>false</isClosed>";
        setInfo += "<color><r>0</r><g>255</g><b>0</b></color>";
        setInfo += "<pointList/>";
        setInfo += "</SnapPolygon>";
        setInfo += "</SnapPolygonList>";
        const iRet = WebVideoCtrl.I_SetSnapPolygonInfo(
          this.g_iWndIndex,
          setInfo
        );
        if (-1 === iRet) {
          szInfo = szInfo + "添加图形失败！";
          return reject(szInfo);
        } else if (-2 === iRet) {
          //alert("参数错误！");
          szInfo = szInfo + "参数错误！";
          return reject(szInfo);
        } else if (-3 === iRet) {
          szInfo = szInfo + "图形个数达到上限！";
          return reject(szInfo);
        } else if (-4 === iRet) {
          szInfo = szInfo + "图形ID已存在！";
          return reject(szInfo);
        }

        WebVideoCtrl.I_SetSnapDrawMode(0, 2);
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 获取多边形信息
  I_GetSnapPolygonInfo = async () => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin I_GetSnapPolygonInfo :";
      try {
        const oWndInfo = await WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        const res = await WebVideoCtrl.I_GetSnapPolygonInfo(this.g_iWndIndex);
        if (res == null) {
          throw new Error("获取多边形信息 失败");
        }
        szInfo = szInfo + "成功";
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 空多边形信息
  I_ClearSnapInfo = async () => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin I_ClearSnapInfo :";
      try {
        const oWndInfo = await WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        const irat = WebVideoCtrl.I_ClearSnapInfo(this.g_iWndIndex);
        if (irat == -1) {
          throw new Error("空多边形信息 失败");
        }

        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 开始对讲
  I_GetAudioInfo = async (params) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 获取对讲通道: ";
      try {
        const oWndInfo = WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }

        const { ip } = params;
        WebVideoCtrl.I_GetAudioInfo(ip, {
          success: function (xmlDoc) {
            const oAudioChannels = $(xmlDoc).find("TwoWayAudioChannel");
            const ids = [];
            $.each(oAudioChannels, function () {
              var id = $(this).find("id").eq(0).text();
              ids.push(id);
              szInfo = szInfo + "获取对讲通道成功";
            });
            resolve(ids);
          },
          error: function (status, xmlDoc) {
            throw new Error((szInfo = szInfo + "获取对讲通道失败！"));
          },
        });
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 开始对讲
  startVoiceTalk = async (params) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 开始对讲: ";
      try {
        const oWndInfo = WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }

        const { ip, channel } = params;
        const iRet = WebVideoCtrl.I_StartVoiceTalk(ip, channel);

        if (0 == iRet) {
          szInfo = szInfo + "开启对讲成功";
          resolve(szInfo);
        } else {
          throw new Error((szInfo = szInfo + "开启对讲失败"));
        }
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 停止
  endVoiceTalk = async () => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 关闭对讲: ";
      try {
        const oWndInfo = WebVideoCtrl.I_GetWindowStatus();
        if (!oWndInfo) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        WebVideoCtrl.I_StopVoiceTalk();
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        resolve(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 开始回放
  I_StartPlayback = async ({ ip, options }) => {
    console.log(ip, options)
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 开始回放: ";
      try {
        WebVideoCtrl.I_StartPlayback(ip, options);
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        resolve(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 开始倒放
  I_ReversePlayback = async ({ ip, options }) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 开始倒放: ";
      try {
        const oWndInfo = WebVideoCtrl.I_ReversePlayback(ip, options);
        if (oWndInfo == -1) {
          szInfo = szInfo + "当前窗口未在播放";
          return reject(szInfo);
        }
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        resolve(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 暂停
  I_Pause = async ({ options }) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 暂停: ";
      try {
        WebVideoCtrl.I_Pause(options);
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        resolve(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 7 恢复播放
  I_Resume = async ({ options }) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 恢复播放: ";
      try {
        WebVideoCtrl.I_Resume(options);
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        resolve(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 7 减速播放
  I_PlaySlow = async ({ options }) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 减速播放: ";
      try {
        WebVideoCtrl.I_PlaySlow(options);
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        resolve(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };

  // 7 加速播放
  I_PlayFast = async ({ options }) => {
    return new Promise(async (resolve, reject) => {
      let szInfo = "plugin 加速播放: ";
      try {
        WebVideoCtrl.I_PlayFast(options);
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        resolve(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  };
}

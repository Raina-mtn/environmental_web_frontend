import 'normalize.css'
// import 'uno.css'
import VPDemo from './components/vp-demo/index.vue'
import './style/css-vars.scss'
import './style/index.scss'

export { VPDemo }

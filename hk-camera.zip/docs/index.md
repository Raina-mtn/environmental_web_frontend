---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: "Basic_Platform_frontend"
  text: "公共平台前端库"
  actions:
    - theme: brand
      text: 安装指南
      link: /guide/index.md
    - theme: alt
      text: 常用组件
      link: /components/UsbCode/index.md

features:
  - icon: 🔨
    title: 基础组件
    details: 基于Element-plus二次封装；
  - icon: ✈️
    title: Vue驱动。
    details: 基于 Vue3 + vite3 的开发
  - icon: '✌️'
    title: 公共平台组件库
    details: pay me a coffee
---


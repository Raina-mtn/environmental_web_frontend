<template>
    <ProTable ref="proTable" :columns="columns" :data="[{}, {}]" :toolButton="true">
        <template #toolButtonInline>
            <el-button type="primary" style="float: right;">行内添加用户</el-button>
        </template>
        <template #toolButton>
            <el-button type="primary">另起一行添加用户</el-button>
        </template>
        <!-- 表格操作 -->
        <template #operation="{ row }">
            <el-button type="primary" link>
                编辑 </el-button>
        </template>
    </ProTable>
</template>
    
<script setup lang='ts'>
import { ColumnProps } from "basic-platform-ui";
const columns: ColumnProps[] = [
    { type: "selection", fixed: "left", width: 80 },
    { type: "index", label: "序号", width: 80 },
    {
        prop: "username",
        label: "账号",
        search: {
            el: "input",
            key: 'usernameLike',
            props: {
                maxlength: 30,
                showWordLimit: true
            }
        }
    },
    {
        prop: "id",
        label: "账号id",
    },
    {
        prop: "mobile",
        label: "手机号",
        search: {
            el: "input", key: 'mobileLike', props: {
                maxlength: 11,
                showWordLimit: true
            }
        }
    },
    {
        prop: "deptName",
        label: "所属部门",
    },
    { prop: "operation", label: "操作", fixed: "right", width: 330 }
];

</script>
    
<style scoped></style>
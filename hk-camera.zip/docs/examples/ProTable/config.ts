
import { ColumnProps } from "basic-platform-ui";
export const columns: ColumnProps[] = [
    { type: "selection", fixed: "left", width: 80 },
    { type: "index", label: "序号", width: 80 },
    {
        prop: "username",
        label: "账号",
        search: {
            el: "input", key: 'usernameLike', props: {
                maxlength: 30,
                showWordLimit: true
            }
        }
    },
    {
        prop: "id",
        label: "账号id",
    },
    {
        prop: "mobile",
        label: "手机号",
        search: {
            el: "input", key: 'mobileLike', props: {
                maxlength: 11,
                showWordLimit: true
            }
        }
    },
    {
        prop: "deptName",
        label: "所属部门",
    },
    { prop: "operation", label: "操作", fixed: "right", width: 330 }
];

<template>
    <ProTable ref="proTable" :columns="columns" :request-api="getTableData" :fetchSetting="fetchSetting"
        :initParam="initParam">
        <!-- 表格操作 -->
        <template #operation="{ row }">
            <el-button type="primary" link>
                编辑 </el-button>
        </template>
    </ProTable>
</template>
    
<script setup lang='ts'>
import { ref } from "vue";
import { columns } from "./config";
import { FetchSetting } from "basic-platform-ui";


const fetchSetting: FetchSetting = {
    listField: 'data',
    totalField: 'total',
}
const initParam = { grade: 1 }
const proTable = ref()

function getTableData(params) {
    console.log(params); // { "grade": 1, "pageIndex": 1, "pageSize": 10}

    // 模拟后台接口数据
    return new Promise((resolve, reject) => {
        const data = { data: [{ username: 'admin' }], total: 100 }
        resolve({ data })
    })
}

</script>
    
<style scoped></style>
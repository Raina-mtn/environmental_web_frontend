<template>
    <!-- 响应式设置 -->
    <h3>响应式设置:</h3>
    <ProTable ref="proTable" :columns="columns" :data="[]" :searchCol="searchColResponsive">
    </ProTable>
    <h3>非响应式设置:</h3>
    <!-- 非响应式设置 -->
    <ProTable ref="proTable" :columns="columns" :data="[]" :searchCol="searchCol">
    </ProTable>
    <h3>非响应式设置 没有新增按钮:</h3>
    <!-- 非响应式设置 没有新增按钮-->
    <ProTable ref="proTable" :columns="columns" :data="[]" :searchCol="searchCol" :toolButtonInline="false">
    </ProTable>
</template>
    
<script setup lang='ts'>
import { ColumnProps } from "basic-platform-ui";

const searchColResponsive = { md: 4, lg: 4, xl: 4 }
const searchCol = 4
const columns: ColumnProps[] = [
    { type: "selection", fixed: "left", width: 80 },
    { type: "index", label: "序号", width: 80 },
    {
        prop: "username",
        label: "账号",
        search: {
            el: "input",
            key: 'usernameLike',
            props: {
                maxlength: 30,
                showWordLimit: true
            }
        }
    },
    {
        prop: "id",
        label: "账号id",
    },
    {
        prop: "mobile",
        label: "手机号",
        search: {
            el: "input", key: 'mobileLike', props: {
                maxlength: 11,
                showWordLimit: true
            }
        }
    },
    {
        prop: "deptName",
        label: "所属部门",
        search: {
            el: "input", key: 'mobileLike', props: {
                maxlength: 11,
                showWordLimit: true
            }
        }
    },
    { prop: "operation", label: "操作", fixed: "right", width: 330 }
];

</script>
    
<style scoped></style>
<template>
    <ProTable ref="proTable" :columns="columns" :request-api="getTableData" :searchCol="4">
        <!-- 表格操作 -->
        <template #operation="{ row }">
            <el-button type="primary" link>
                编辑 </el-button>
        </template>
    </ProTable>
</template>
    
<script setup lang='ts'>
import { ref } from "vue";
import { ColumnProps } from "basic-platform-ui";
const proTable = ref()
const columns: ColumnProps[] = [
    { type: "selection", fixed: "left", width: 80 },
    { type: "index", label: "序号", width: 80 },
    {
        prop: "userId",
        label: "格式化数据",
        search: {
            el: "select", key: 'userId'
        },
        enum: [{ label: '小明', value: 1 }, { label: '小红', value: 2 }],
    },
    {
        prop: "username",
        label: "不必格式化",
        search: {
            el: "select", key: 'username'
        },
        enum: [{ label: '小明', value: 1 }, { label: '小红', value: 2 }],
        isFilterEnum: false
    },
    {
        prop: "mobile",
        label: "手机号",
        search: {
            el: "input", key: 'mobileLike', props: {
                maxlength: 11,
                showWordLimit: true
            }
        }
    },
];
function getTableData(params) {
    // 模拟后台接口数据
    return new Promise((resolve, reject) => {
        const data = { list: [{ userId: 1, username: '小明' }] }
        resolve({ data })
    })
}

</script>
    
<style scoped></style>
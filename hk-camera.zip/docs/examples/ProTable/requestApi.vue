<template>
    <ProTable ref="proTable" :columns="columns" :request-api="getTableData">
        <!-- 表格操作 -->
        <template #operation="{ row }">
            <el-button type="primary" link>
                编辑 </el-button>
        </template>
    </ProTable>
</template>
    
<script setup lang='ts'>
import { columns } from "./config";
function getTableData() {
    // 模拟后台接口数据
    return new Promise((resolve, reject) => {
        const data = { list: [{ username: 'admin' }] }
        resolve({ data })
    })
}

</script>
    
<style scoped></style>
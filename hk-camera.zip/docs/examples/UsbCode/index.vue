<template>
    <UsbCode type="primary"></UsbCode>
</template>
    
<script setup lang='ts'>

</script>
    
<style></style>
<template>
    <div>
        <el-from label-width="150px">
            <el-form-item label="前端加密公钥">
                <el-input v-model="state.frontKeys.publicKey" disabled />
            </el-form-item>
            <el-form-item label="前端解密私钥">
                <el-input :value="state.frontKeys.privateKey" disabled></el-input>
            </el-form-item>
            <el-form-item label="加密签名(对admin加密)">
                <el-input v-model="state.sign"></el-input>
                <el-button @click="doSign">加密</el-button>
            </el-form-item>
            <el-form-item label="后端加密公钥">
                <el-input v-model="endKeys.publicKey"></el-input>
            </el-form-item>
            <el-form-item label="后端解密私钥">
                <el-input v-model="endKeys.privateKey"></el-input>
            </el-form-item>
            <el-form-item label="数据加解密">
                <el-input v-model="state.endData"></el-input><el-button @click="toggleEncryParamsFromEnd">{{ state.isencry ?
                    '解密' : '加密' }}</el-button>
            </el-form-item>
        </el-from>
    </div>
</template>
<script setup lang="ts">
import { ElMessage } from 'element-plus'
import { useCrypto } from '@basic-platform-ui/utils'
import { reactive } from 'vue';

const endKeys = reactive({
    publicKey: '043cb4046556b0addb903a8e4a4f46db923028429d1408897a9f256d5bd72a137029d21be2d8cb2c79bdb426deeeede8744786bf498d16556e616df274692ba007',
    privateKey: '',
})

// 模拟请求后端公钥接口
const requestPublicKeyApi = () => new Promise((resolve, reject) => {
    resolve({
        data: JSON.stringify({
            publicKey: endKeys.publicKey,
            enable: '1',
            noEncryUrlList: []
        })
    })
})

// 模拟发送后端公钥接口
const postFrontKeyApi = () => new Promise((resolve, reject) => {
    resolve({
        data: "admin"
    })
})


const { frontKeys, getSign, encryptParams, getSm2DataByEndKey } = useCrypto(requestPublicKeyApi, postFrontKeyApi, { publicKey: endKeys.publicKey, privateKey: endKeys.privateKey })
const state = reactive({
    frontKeys: {
        publicKey: frontKeys.publicKey,
        privateKey: frontKeys.privateKey
    },
    signUserName: 'admin',
    sign: '',
    isencry: false, //是否是加密模式 
    endData: 'admin',
})


async function doSign() {
    state.sign = await getSign()
}

async function toggleEncryParamsFromEnd() {
    if (!state.isencry) {
        state.endData = await encryptParams(state.endData)
    } else {
        if (!endKeys.privateKey) return ElMessage.error('请先输入后端解密私钥')
        state.endData = await getSm2DataByEndKey(state.endData)
    }
    state.isencry = !state.isencry

}


</script>
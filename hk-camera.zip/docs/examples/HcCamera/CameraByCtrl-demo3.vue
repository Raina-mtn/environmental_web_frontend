<template>
  <CameraByCtrl style="height: 400px" :ctrl="hcCameraController" @init="init" />
  <p>{{ hcCameraController?.choosedCamrea?.playStatus }}</p>
  <el-button-group class="ml-4">
    <el-date-picker
      v-model="state.timeRange"
      type="datetimerange"
      range-separator="To"
      start-placeholder="Start date"
      end-placeholder="End date"
    />
    <el-divider content-position="left">控制当前选中的相机</el-divider>
    <el-button
      type="primary"
      :icon="Edit"
      @click="
        hcCameraController?.choosedCamrea?.startBackPlay({
          szStartTime: state.timeRange[0],
          szEndTime: state.timeRange[1],
        })
      "
      >开始回放</el-button
    >
    <el-button
      type="primary"
      :icon="Edit"
      @click="hcCameraController?.choosedCamrea?.I_PlaySlow()"
      >减速播放</el-button
    >
    <el-button
      type="primary"
      :icon="Edit"
      @click="hcCameraController?.choosedCamrea?.I_PlayFast()"
      >加速播放</el-button
    >
    <el-button
      type="primary"
      :icon="Edit"
      @click="hcCameraController?.choosedCamrea?.I_Pause()"
      >暂停</el-button
    >
    <el-button
      type="primary"
      :icon="Edit"
      @click="hcCameraController?.choosedCamrea?.I_Resume()"
      >恢复播放</el-button
    >
  </el-button-group>
</template>
<script setup lang="ts">
import { reactive } from "vue";
import { uniqueId } from "lodash-es";
import { CameraControllers, CameraByCtrl } from "basic-platform-ui";
import {
  ArrowLeft,
  ArrowRight,
  Delete,
  Edit,
  Share,
} from "@element-plus/icons-vue";

// 生成 controller
const { HcCameraController, pending } = CameraControllers;
let ctrl = new HcCameraController({ ele: uniqueId("camera_") });
let hcCameraController = reactive(ctrl);

// 生成 cameraData;
const state = reactive({
  cameraData: {
    channel: "1",
    ip: "172.16.190.101",
    username: "admin",
    password: "shenhao123",
    port: 80,
    presetIndex: 0,
  },
  timeRange: ["2023-12-19 00:00:00", "2023-12-19 23:59:59"],
});

// @ts-ignore
// hcCameraController.setOptions({ cameras: [cameraData] });

// 监听 插件初始化成功
const init = async () => {
  await hcCameraController.setOptions({
    cameras: [
      state.cameraData,
      {
        channel: "1",
        ip: "172.17.6.81",
        username: "admin",
        password: "abcd1234",
        port: 80,
        presetIndex: 0,
      },
    ],
  });
  await hcCameraController.setWnd(1);
  await pending(1000);
  await hcCameraController.getPluginCfg();
};
</script>

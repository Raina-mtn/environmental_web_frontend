<template>
  <CameraDialog ref="cameraRef" />
  <el-button @click="seeCamera">打开播放窗口</el-button>
</template>
<script setup lang="ts">
import { CameraDialog } from "basic-platform-ui";
import { ref } from "vue";

const cameraRef = ref();
const seeCamera = async (rowData) => {
  const cameraData = {
    channel: "1",
    ip: "172.17.6.81",
    username: "admin",
    password: "abcd1234",
    port: 80,
    presetIndex: 0,
  };
  cameraRef.value.open(cameraData);
};
</script>

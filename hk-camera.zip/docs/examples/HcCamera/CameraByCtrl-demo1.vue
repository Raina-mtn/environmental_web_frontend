<template>
  <div style="height:400px">
    <CameraByCtrl :cameraData="cameraData" />
  </div>
</template>
<script setup lang="ts">
import { CameraByCtrl } from "basic-platform-ui";

// 生成 cameraData;
const cameraData = {
  channel: "1",
  ip: "172.17.6.81",
  username: "admin",
  password: "abcd1234",
  port: 80,
  presetIndex: 0,
};
</script>

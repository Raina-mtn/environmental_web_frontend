<template>
  <CameraByCtrl style="height: 400px" :ctrl="hcCameraController" @init="init" />
  <el-button-group class="ml-4">
    <el-divider content-position="left">控制当前选中的相机</el-divider>

    <el-button
      type="primary"
      :icon="Edit"
      @click="hcCameraController?.startAllPlay()"
      >打开列表</el-button
    >
    <el-button
      type="primary"
      :icon="Edit"
      @click="hcCameraController?.stopAllPlay()"
      >关闭列表</el-button
    >
  </el-button-group>
</template>
<script setup lang="ts">
import { reactive } from "vue";
import { uniqueId } from "lodash-es";
import { CameraControllers, CameraByCtrl } from "basic-platform-ui";
import {
  ArrowLeft,
  ArrowRight,
  Delete,
  Edit,
  Share,
} from "@element-plus/icons-vue";

// 生成 controller
const { HcCameraController, pending } = CameraControllers;
let ctrl = new HcCameraController({ ele: uniqueId("camera_") });
let hcCameraController = reactive(ctrl);

// 生成 cameraData;
const state = reactive({
  cameraData: [
    {
      channel: "1",
      ip: "172.17.6.81",
      username: "admin",
      password: "abcd1234",
      port: 80,
      presetIndex: 0,
    },
    {
      channel: "1",
      ip: "172.16.190.101",
      username: "admin",
      password: "shenhao123",
      port: 80,
      presetIndex: 0,
    },
    {
      channel: "2",
      ip: "172.16.190.101",
      username: "admin",
      password: "shenhao123",
      port: 80,
      presetIndex: 0,
    },
    {
      channel: "4",
      ip: "172.16.190.101",
      username: "admin",
      password: "shenhao123",
      port: 80,
      presetIndex: 0,
    },
  ],
});

// 监听 插件初始化成功
const init = async () => {
  await hcCameraController.setOptions({
    cameras: state.cameraData,
  });
  await hcCameraController.setWnd(2);
  await pending(1000);
  await hcCameraController.getPluginCfg();
};
</script>

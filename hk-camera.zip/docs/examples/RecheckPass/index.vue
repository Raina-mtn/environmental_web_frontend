<template>
    <div>
        <el-button @click="recheck" type="primary"> 点击弹出二次鉴别弹窗</el-button>
    </div>
</template>
<script setup lang="ts">
import { recheckPass } from 'basic-platform-ui'

// 模拟异步请求
const checkPassApi = (res) => new Promise((resolve, reject) => {
    alert(JSON.stringify(res))
    resolve('')
})

async function recheck() {
    await recheckPass(checkPassApi)
}

</script>
# 安装

- ### 步骤1： 设置dns为172.19.4.180
<img src="/images/dns.png" width=500>


- ### 步骤2： 设置项目内npm源.npmrc
``` js
basic-platform-ui:registry=http://nexus.shinforobot.com/repository/common-ui/
```

- ### 步骤3： 安装
``` shell
pnpm install basic-platform-ui
```
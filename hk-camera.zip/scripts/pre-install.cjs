// import fs from 'fs'
// import path from 'path'
const fs = require('fs')
const path = require('path')

async function main() {
    console.log('使用usbcode需要在public目录下生成iframe文件，请稍候...')
    const rootPath = process.cwd().split('\\node_modules')[0]
    const outdirPath = path.join(process.cwd(), 'public')
    const inputDirPath = path.join(rootPath, 'public')

    getFiles(outdirPath, inputDirPath)
    function getFiles(ipkDirPath, newIpkPath) {
        //读取newFile文件夹下的文件
        fs.readdir(ipkDirPath, { withFileTypes: true }, (err, files) => {
            for (let file of files) {
                //判断是否是文件夹，不是则直接复制文件到newFile中
                if (!file.isDirectory()) {
                    //获取旧文件夹中要复制的文件
                    const OriginFile = path.resolve(ipkDirPath, file.name)
                    //获取新文件夹中复制的地方
                    const CopyFile = path.resolve(newIpkPath, file.name)
                    //将文件从旧文件夹复制到新文件夹中
                    fs.copyFileSync(OriginFile, CopyFile)
                } else {//如果是文件夹就递归变量把最新的文件夹路径传过去
                    const CopyDirPath = path.resolve(newIpkPath, file.name)
                    const OriginDirPath = path.resolve(ipkDirPath, file.name)
                    fs.mkdir(CopyDirPath, (err) => {

                    })
                    // OriginFilePath = OriginPath
                    // CopyFilePath = DirPath
                    getFiles(OriginDirPath, CopyDirPath)
                }
            }
        })
    }

}

main()
import { reactive, ref, unref } from "vue";
import pkg from 'sm-crypto';
const { sm2, sm3 } = pkg;
// import { sm2, sm3 } from 'sm-crypto'

export function useCrypto(requestPublicKeyApi: PromiseFn, postFrontKeyApi: PromiseFn, option = { sm2PublicKey: '', sm2PrivatKey: '' }) {
    const frontKeys = sm2.generateKeyPairHex()// 前端钥匙对
    const enable = ref(0) // 是否允许加密
    const sign = ref('') // 请求头签名
    const sm2PublicKey = ref(option.sm2PublicKey || '') // 系统后台公钥
    const sm2PrivatKey = ref(option.sm2PrivatKey || '') // 系统后台私钥
    const noEncryUrlList = reactive<string[]>([])

    // 获取后端公钥，初始化参数
    async function initSm2PublicKey() {
        if (!unref(sm2PublicKey)) {
            try {
                const { data } = await requestPublicKeyApi()
                const { publicKey, enable: enableFormEnd, noEncryUrlList: noEncryUrlListFromEnd } = JSON.parse(data)
                sm2PublicKey.value = publicKey
                enable.value = Number(enableFormEnd)
                noEncryUrlList.push(...(noEncryUrlListFromEnd || []))
            } catch (error) {
                console.error('getSm2PublicKey:', error)
            }
        }
    }
    // 请求数据加密
    function getSm2DataHex(value: any) {
        const data = value + '/' + sm3(value)
        const res = '04' + sm2.doEncrypt(data, sm2PublicKey.value, 0) // 前端用cipherMode=0 加密
        return res
    }

    // 把前端公钥发给后端，验证签名加密
    async function getSign() {
        console.log(sign);

        if (!unref(sign)) {
            const { data } = await postFrontKeyApi(frontKeys.publicKey)
            // console.log('pulic 返回值data', data);
            if (data && typeof data === 'string') {
                const str = data.replace(/^\"|\"$/g, '') // 去掉头尾双引号
                sign.value = sm2.doSignature(str, frontKeys.privateKey, { hash: true, der: true })
            }
        }
        return sign.value
    }

    // 前端解密
    function getSm2DataByFrontKey(dataHex: string) {
        if (dataHex && typeof dataHex === 'string') {
            let result = dataHex.substring(2).toLocaleLowerCase()
            const data = sm2.doDecrypt(result, frontKeys.privateKey, 1) // 解密后端 用cipherMode=1 解密
            return data
        }
    }

    // 解密后端 测试
    async function getSm2DataByEndKey(dataHex: any, privateKey) {
        if (privateKey) {
            sm2PrivatKey.value = privateKey
        }
        let result: any
        if (dataHex && (typeof dataHex === 'string')) {
            result = dataHex.substring(2)
            const str = sm2.doDecrypt(result, sm2PrivatKey, 0)
            // console.log('解密:', str);
            return str
        } else if (Object.prototype.toString.call(dataHex) == '[object Object]') {
            result = {}
            for (const [key, value] of Object.entries(dataHex)) {
                const str = value && typeof value === 'string' ? value.substring(2) : ''
                result[key] = sm2.doDecrypt(str, sm2PrivatKey, 0)
            }
            return result
        }
    }

    // 加密传参
    async function encryptParams(data: any, forceEncrypto?: boolean) {
        // 检查是否获取过
        await initSm2PublicKey()
        // 加密模式下获取签名值
        if (unref(enable)) {
            await getSign()
        }

        let encryptoEnable = unref(enable)
        if (forceEncrypto != null) {
            encryptoEnable = forceEncrypto ? 1 : 0;
        }
        let returnData = data
        if (encryptoEnable == 1) {
            if (Object.prototype.toString.call(data) == '[object FormData]') {
                returnData = new FormData()
                for (const [key, value] of data.entries()) {
                    let encryptValue = await getSm2DataHex(value)
                    returnData.set(key, encryptValue)
                }
            } else if ((Object.prototype.toString.call(data) == '[object Object]' || Object.prototype.toString.call(data) == '[object Array]')) {
                const str = JSON.stringify(data)
                returnData = await getSm2DataHex(str)
            } else {
                returnData = await getSm2DataHex(data)
            }
        }
        return returnData
    }



    return {
        getSm2DataHex,
        getSign,
        getSm2DataByFrontKey,
        encryptParams,
        getSm2DataByEndKey,
        noEncryUrlList,
        sign,
        frontKeys
    }
}
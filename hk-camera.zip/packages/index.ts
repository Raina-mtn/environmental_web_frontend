import type { Component, App } from 'vue'

import UsbCode from './components/UsbCode'
import ProTable from './components/ProTable'
import RecheckPass from './components/RecheckPass'
import { useCrypto } from './utils'
import {
    CameraByCtrl,
    CameraByUrl,
    CameraDialog,
    CameraControllers
} from './components/HcCamera'

// 存储组件列表
const components: {
    [propName: string]: Component
} = {
    UsbCode,
    ProTable,
    CameraByCtrl,
    CameraByUrl,
    CameraDialog,
}

// 插件声明：声明所有插件
const installComponents: any = (app: App) => {
    for (const key in components) {
        app.component(key, components[key])
    }
}

// vue插件
// - install：每个插件都有一个 install 方法
// - 参数：是通过 Vue.createApp() 创建的 app 实例
const install: any = (app: any, router?: any) => {
    // !router && installRouter(app);
    installComponents(app)
}

// 按需引入
export {
    UsbCode,
    RecheckPass,
    ProTable,
    useCrypto,
    CameraByCtrl,
    CameraByUrl,
    CameraDialog,
    CameraControllers
}
export default {
    // 导出的对象必须具有 install，才能被 Vue.use() 方法安装
    install,
}
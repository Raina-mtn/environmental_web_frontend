import UsbCode from './src/index.vue'
import { withInstall } from '../withInstall'

const PUsbCode = withInstall(UsbCode)
export default PUsbCode
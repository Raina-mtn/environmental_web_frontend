<template>
    <div class="usbCode">
        <el-input readonly v-model="state.value" placeholder="请点击读取获得U盾密码">
        </el-input>
        <el-button @click="read" v-bind="$attrs"> 读取 </el-button>
        <iframe v-if="state.src" ref="iframe_usbCode" style="width: 1px; height: 1px"
            src="./ipk/chrome/ipk_chrome_extension.html" />
    </div>
</template>

<script lang="ts" setup name="UsbCode">
import { reactive, ref, onBeforeMount, watch } from "vue";

const props = defineProps({
    value: {
        type: String,
        default: "",
        required: false,
    },
});

const emit = defineEmits(["update:value"]);

const state = reactive({
    value: "",
    src: "",
});

watch(
    () => props.value,
    (newVal) => {
        state.value = newVal;
    }
);

const userAgent = () => {
    var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
    var isOpera = userAgent.indexOf("Opera") > -1;
    if (isOpera) {
        //判断是否Opera浏览器
        return "Opera";
    }
    if (userAgent.indexOf("Firefox") > -1) {
        //判断是否Firefox浏览器
        state.src = "/ipk/firefox/ipk_firefox_extension.html";
        return "FF";
    }
    if (userAgent.indexOf("Chrome") > -1) {
        //判断是否Chrome浏览器
        state.src = "/ipk/chrome/ipk_chrome_extension.html";
        return "Chrome";
    }
};


const iframe_usbCode = ref();
const read = async () => {
    const res = await iframe_usbCode.value.contentWindow.TestOpenDevice()
    const ucide = res ? JSON.parse(res).responseData : ''
    state.value = ucide
    if (/[0-9]+/.test(ucide)) {
        emit('update:value', ucide)
        return ucide
    } else {
        emit('update:value', '')
        return ''
    }
}

defineExpose({ read })
onBeforeMount(() => {
    userAgent();
});
</script>
<style lang="scss" scoped>
.usbCode {
    display: flex;
}
</style>

import { recheckPass } from './src/index'
export { recheckPass }
export default recheckPass
import RecheckPass from './index.vue'
import { h, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

let checkInstance = reactive({ func: () => { } })

function getCheckFunc(func: PromiseFn) {
    checkInstance.func = func
}
// 二次确认
export function recheckPass(checkApi: PromiseFn) {
    return new Promise<void>((resolve, reject) => {
        ElMessageBox({
            title: '操作再确认',
            message: h(RecheckPass, {
                callback: getCheckFunc
            }),
            showCancelButton: true,
            beforeClose(action, instance, done) {
                checkInstance.func().then(async (res) => {
                    await checkApi(res)
                    console.log('二次鉴别成功');
                    resolve()
                    done()
                }).catch(() => {
                    console.log('二次鉴别失败');
                    reject()
                    done()

                })
            },
        })
    })

}
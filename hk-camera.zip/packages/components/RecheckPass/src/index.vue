<template>
    <div>
        <el-form ref="ruleFormRef" :model="formdata" :rules="rules" label-width="100" class="demo-ruleForm" status-icon
            size="large">
            <el-form-item label="用户名" prop="username">
                <el-input v-model="formdata.username" placeholder="请输入用户名" />
            </el-form-item>
            <el-form-item label="密码" prop="password">
                <el-input type="password" v-model="formdata.password" show-password placeholder="请输入密码" />
            </el-form-item>
        </el-form>
        <UsbCode v-model:value="formdata.ucode" style="visibility: hidden" ref="UsbCodeRef"></UsbCode>
    </div>
</template>
<script setup lang="ts">
import UsbCode from '../../UsbCode/src/index.vue'
import { reactive } from 'vue';
import { ref } from 'vue';
import { onMounted } from 'vue';

const props = defineProps(['callback', 'text'])

const ruleFormRef = ref()
const UsbCodeRef = ref()
const formdata = reactive({
    password: '',
    ucode: '',
    username: ''
})
const rules = {
    username: [{ required: true, message: '请输入用户名', trigger: "change" }],
    password: [{ required: true, message: '请输入密码', trigger: "change" }],
}

async function submit() {
    await ruleFormRef.value.validate();
    let params, ucode = ''
    try {
        ucode = await UsbCodeRef.value.read()

    } catch (error) {
        console.log(error);

    }
    params = {
        password: formdata.password,
        username: formdata.username,
        ucode
    }
    return params
}

onMounted(() => {
    props.callback && props.callback(submit)
})

defineExpose({
    open,
});

</script>
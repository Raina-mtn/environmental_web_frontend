<script lang="ts" setup>
import { reactive, watch } from "vue";
import { HcCameraController, pending } from "../../cameraController";
import { debounce, uniqueId } from "lodash-es";
const props = defineProps({
  cameraData: {
    type: Object,
    default: null,
    required: false,
  },
  ctrl: {
    type: HcCameraController,
    default: null,
    required: false,
  },
});

let hcCameraController = reactive(
  new HcCameraController({
    ele: uniqueId("camera_"),
  })
);

watch(
  () => props.ctrl,
  async (ctrl) => {
    if (!ctrl) return;
    hcCameraController = ctrl;
  },
  { deep: true, immediate: true }
);

watch(
  () => props.cameraData,
  async (cameraData) => {
    autoStartPlay(cameraData);
  },
  { deep: true }
);

const emit = defineEmits(["init"]);

const autoStartPlay = debounce(async (cameraData) => {
  if (!cameraData) return;

  const { channel, ip, password, port, presetIndex, username } = cameraData;
  if (!channel || !ip || !password || !port || !username) {
    console.warn("参数缺少，无法自动播放");
    return;
  }
  await hcCameraController?.setWnd(1);
  await hcCameraController.setOptions({
    cameras: [cameraData],
  });

  await hcCameraController.startAllPlay();
}, 500);

const initCamera = debounce(async () => {
  await hcCameraController.initPlugin();
  autoStartPlay(props.cameraData);
  emit("init");
}, 500);
</script>

<template>
  <iframe
    class="windows"
    @load="initCamera"
    :key="hcCameraController.ele"
    :id="hcCameraController.ele"
    :src="`/hclib/v3.0/index.html`"
    frameborder="0"
  />
</template>

<style lang="scss" scoped>
.windows {
  width: 100%;
  height: 100%;
}
</style>

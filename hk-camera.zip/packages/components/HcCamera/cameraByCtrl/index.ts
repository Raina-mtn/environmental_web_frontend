import CameraByCtrl from "./src/index.vue";

import { withInstall } from '../../withInstall'

const useCameraByCtrl = withInstall(CameraByCtrl)

export default useCameraByCtrl
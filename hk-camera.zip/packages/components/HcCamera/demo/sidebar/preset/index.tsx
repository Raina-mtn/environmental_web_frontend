import {
  defineComponent,
  ref,
  watch,
} from "vue";
import { getPresetList, deletePreset } from "@/api/interface";
import Form from "./form.vue";
import "./index.scss";
import { ElMessage } from 'element-plus'
import { debounce } from "lodash-es";

export default defineComponent({
  props: {
    hcCameraController: Object,
  },
  setup(props) {
    watch(
      () => props.hcCameraController?.reactiveData.choosedCamrea,
      async (choosedCamrea) => {
        if (!choosedCamrea) return;
        console.log("choosedCamrea", choosedCamrea);
        setPresetList();
      },
      { immediate: true }
    );

    const presetname = ref('')

    const list = ref([]);
    const setPresetList = debounce(
      async (presetname: any = '') => {
        const { ip } = props.hcCameraController?.reactiveData.choosedCamrea.equipment;
        const { channel } = props.hcCameraController?.reactiveData.choosedCamrea
        list.value = await getPresetList({
          presetip: ip,
          presetchannel: channel,
          presetname
        }).then((res) => res.data);
      },
      800
    )

    const deletePresetFun = (item) => {
      const { ip } = props.hcCameraController?.reactiveData.choosedCamrea.equipment;
      const { channel } = props.hcCameraController?.reactiveData.choosedCamrea;
      const data = {
        presetindex: item.presetindex,
        presetip: ip,
        presetchannel: channel
      }
      deletePreset(data).then(res => {
        setPresetList();
        ElMessage.success("删除成功");
      })
    }

    return () => (
      <div class={"preset"}>
        <div class={"title"}>
          <p>
            {props.hcCameraController?.reactiveData?.choosedCamrea?.data.cnDesc}
          </p>
          <Form
            getList={setPresetList}
            formData={{
              presetip:
                props.hcCameraController?.reactiveData.choosedCamrea
                  ?.equipment?.ip,
              presetchannel:
                props.hcCameraController?.reactiveData.choosedCamrea
                  ?.channel,
              presetindex: 0,
              presetname: '',
            }}

          >
            <el-button
              disabled={!props.hcCameraController?.reactiveData.choosedCamrea}
              size="small">添加</el-button>
          </Form>
        </div>
        <div class={"body"}>
          <el-input v-model={presetname.value} onInput={(e) => setPresetList(e)} />
          <el-scrollbar style="height: calc(100% - 37px);">
            {list.value.map((item, index) => (
              <div class={"body-item"}>
                <p class={"item-desc"}>{item?.presetname}</p>
                <el-tooltip content="调用预置位" effect="customized">
                  <div
                    class={"item-btn"}
                    onClick={async () => {
                      await props.hcCameraController?.reactiveData.choosedCamrea.goPreset(
                        item.presetindex
                      )
                      ElMessage.success("调用成功");
                    }
                    }
                  />
                </el-tooltip>

                <Form
                  getList={setPresetList}
                  formData={{
                    presetip:
                      props.hcCameraController?.reactiveData.choosedCamrea
                        .equipment.ip,
                    presetchannel:
                      props.hcCameraController?.reactiveData.choosedCamrea
                        .channel,
                    presetindex: item?.presetindex,
                    presetname: item?.presetname,
                  }}
                >
                  <div class={"item-btn"} />
                </Form>
                <el-popconfirm
                  onConfirm={() => deletePresetFun(item)}
                  title="是否要删除？"
                  v-slots={{
                    reference: () => {
                      return (
                        <>
                          <div class={"item-btn"} />
                        </>
                      )
                    }
                  }} />
              </div>
            ))}
          </el-scrollbar>
        </div>
      </div>
    );
  },
});

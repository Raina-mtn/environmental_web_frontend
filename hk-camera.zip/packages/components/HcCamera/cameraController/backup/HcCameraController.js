import Equipment from "./equipment";
import CommunicateWidthIframe from "./communicate";
import { reactive, watch } from "vue";
import { pending } from "./utils";
import Camera from "./camera";

export default class HcCameraController {
  // 设备列表
  equipmentList = [];

  // 播放列表
  pageIndex = 1;
  pageSize = 4;
  total = 0;
  searchParams = {
    robotcode: "",
  };
  cameraList = [];
  cameraListData = [];
  pagingStatus = "succeed"; // succeed failed, loading;
  g_iWndIndex = 0;
  pluginCfg = {
    recordPath: "",
    capturePath: "",
  };
  // choosedCamrea = null;
  playAllTaggle = "played"; // closing closed
  size = {
    top: 0,
    left: 0,
    height: 2,
    width: 2,
  };

  // 通信封装
  communicate = null;

  // 窗口类型
  iWndowType = 1;

  getList = async (reactiveData) => {
    const { pageIndex, pageSize, cameraListData } = reactiveData;
    const start = (pageIndex - 1) * pageSize;
    const end = pageIndex * pageSize;
    const cameraPlayListData = cameraListData.slice(start, end);
    return { playList: cameraPlayListData, total: cameraListData.length };
  };

  // 监听窗口点击
  clickListener = [];

  // 直接设置
  constructor({ ele }) {
    if (ele) {
      this.ele = ele;
      CommunicateWidthIframe.initCommunicate();
    }

    this.initListener();
  }

  get choosedCamrea() {
    return this.cameraList[this.g_iWndIndex] ?? null;
  }

  addClickListener(func) {
    this.clickListener.push(func);
  }

  removeClickListener(func) {
    let index = this.clickListener.indexOf(func);
    this.clickListener.splice(index, 1);
  }

  handleSearch() {}

  initListener() {
    window.addEventListener("message", (event) => {
      const { contentType, params, iframeId } = event.data;
      if (contentType && contentType == "g_iWndIndex" && this.ele == iframeId) {
        this.g_iWndIndex = params.g_iWndIndex;
        this.clickListener.map((item) => item());
      }
    });
  }

  // 初始化插件
  async initPlugin() {
    CommunicateWidthIframe.connect(this.ele, { connectType: "initPlugin" });
  }

  // equipments [{ ip, port, username, password, data }]
  // cameras [{ ip, port, username, password, data, channel }]
  setOptions({ equipments, cameras, getList }) {
    // 设置设备表
    if (equipments) {
      this.equipmentList = equipments.reduce((pre, cur) => {
        let { ip, port, username, password, data } = cur;
        let newQuip = new Equipment({
          ip,
          port,
          username,
          password,
          data,
          ele: this.ele,
        });
        pre.push(newQuip);
        return pre;
      }, []);
    }

    // 设置相机
    if (cameras) {
      this.cameraListData = cameras;
    }

    if (getList) {
      this.getList = getList;
    }
  }

  async getCameraByEquipment() {
    for (const equipment of this.equipmentList) {
      const cameras = await equipment.getCameras();
      // 获取完成后塞入相机列表
      this.cameraListData = [...this.cameraListData, ...cameras];
      // 开始播放
      await this.startPlayCameraList();
    }
  }

  /// 相机开始播放
  async startPlayCameraList() {
    const { playList: newPlayListData, total } = await this.getList(this);

    // 设置总的播放个数
    this.total = total;

    // 生成要关闭的列表
    let endPlayCameras = this.cameraList.filter((camera) => {
      let newPlayItem = newPlayListData.find(
        ({ ip, port, channel }, iWndIndex) => {
          return (
            camera.equipment.ip == ip &&
            camera.equipment.port == port &&
            camera.channel == channel &&
            camera.iWndIndex == iWndIndex
          );
        }
      );
      return newPlayItem == null ? true : false;
    });
    console.log("endPlayCamera>>>>>>", endPlayCameras);
    const endFuns = endPlayCameras.map((item) => item.stopPlayAndClear());
    await Promise.allSettled(endFuns);

    // 获取将要播放的列表
    let newCameraList = [];
    newPlayListData.forEach((cameraData, iWndIndex) => {
      let playedCamera = this.cameraList.find((camera) => {
        return (
          camera.equipment.ip == cameraData.ip &&
          camera.equipment.port == cameraData.port &&
          camera.channel == cameraData.channel &&
          camera.iWndIndex == iWndIndex
        );
      });

      if (!playedCamera) {
        // 检查是否存在equipment
        let equipment = this.equipmentList.find(
          (equip) =>
            equip.ip === cameraData.ip && equip.port === cameraData.port
        );
        let { ip, port, username, password, data } = cameraData;
        if (!equipment) {
          equipment = new Equipment({
            ip,
            port,
            username,
            password,
            data,
            ele: this.ele,
          });
          this.equipmentList.push(equipment);
        }

        playedCamera = reactive(
          new Camera({
            channel: cameraData.channel,
            equipment,
            data,
            ele: this.ele,
          })
        );
      }
      newCameraList.push(playedCamera);
    });

    const startFuns = newCameraList.map((item, index) =>
      item.startRealPlay({ iWndIndex: index })
    );
    this.cameraList.length = 0;
    this.cameraList.push(...newCameraList)

    await Promise.allSettled(startFuns);
    return true;
  }

  /// 固定列表分页
  async handleSizePageChange({ pageIndex, pageSize }) {
    try {
      console.log("handleSizePageChange>>>", pageIndex, pageSize);
      if (pageSize && pageSize != this.pageSize) {
        this.pageSize = pageSize;
      }

      if (pageIndex && pageIndex != this.pageIndex) {
        this.pageIndex = pageIndex;
      }

      if (this.pagingStatus == "loading") {
        return;
      }
      this.pagingStatus = "loading";

      const curIWndowType = Math.sqrt(this.pageSize);
      // 增加行数
      if (this.iWndowType < curIWndowType) {
        await this.changeWndNum(curIWndowType);
        await pending(1000);
      }

      // await this.constantList_cameraListStartRealPlay()
      await this.startPlayCameraList();

      // 减少行数
      if (this.iWndowType > curIWndowType) {
        await this.changeWndNum(curIWndowType);
      }
      console.log("handleSizePageChange>>>> succcess");
      this.pagingStatus = "succeed";
    } catch (error) {
      console.error("handleSizePageChange>>>", error);
      this.pagingStatus = "fail";
    }
  }

  // 设置插件的大小
  async resize({ width, height, left, top }) {
    this.size.width = width + Math.random() * 1;
    this.size.height = height + Math.random() * 1;
    this.size.left = left;
    this.size.top = top;
  }

  // 窗口分割数
  changeWndNum(iType) {
    return new Promise(async (resolve, reject) => {
      let szInfo = "窗口分割：";
      try {
        const res = await CommunicateWidthIframe.connect(this.ele, {
          connectType: "changeWndNum",
          params: { iType },
        });
        szInfo = szInfo + "成功";
        this.iWndowType = iType;
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  // 播放窗口和页码等
  async setWnd(iWndowType) {
    this.pageSize = iWndowType * iWndowType;
    return this.changeWndNum(iWndowType);
  }

  async getPluginCfg() {
    return new Promise(async (resolve, reject) => {
      let szInfo = "获取插件参数：";
      try {
        const res = await CommunicateWidthIframe.connect(this.ele, {
          connectType: "I_GetLocalCfg",
        });
        szInfo = szInfo + "成功";
        this.pluginCfg.recordPath = res.RecordPath;
        this.pluginCfg.capturePath = res.CapturePath;
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  // 打开文件选择框
  async openPluginDir() {
    return new Promise(async (resolve, reject) => {
      let szInfo = "打开文件夹选择器：";
      try {
        const res = await CommunicateWidthIframe.connect(this.ele, {
          connectType: "I_OpenFileDlg",
          params: { iType: 0 },
        });
        if (res) {
          szInfo = szInfo + "成功";
          resolve(res);
        } else {
          szInfo = szInfo + "失败- 没有选择";
          reject(szInfo);
        }
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  // 设置参数
  async setPluginCfg(params) {
    return new Promise(async (resolve, reject) => {
      let szInfo = "设置插件参数：";
      try {
        const res = await CommunicateWidthIframe.connect(this.ele, {
          connectType: "I_SetLocalCfg",
          params,
        });
        szInfo = szInfo + "成功";
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async stopOrStartAllPlay() {
    return new Promise(async (resolve, reject) => {
      let szInfo = "开始停止或播放所有预览:";
      if (this.playAllTaggle == "closing") {
        szInfo = szInfo + "关闭中";
        return reject(szInfo);
      }
      try {
        const operateCameraList = this.cameraList.filter(
          (item) => item.iWndIndex != null
        );
        if (this.playAllTaggle == "played") {
          this.playAllTaggle = "closing";
          let queue = operateCameraList.map((item) => item.stopPlay());
          await Promise.allSettled(queue);
          this.playAllTaggle = "closed";
          szInfo = szInfo + "关闭成功";
          return resolve(szInfo);
        } else if (this.playAllTaggle == "closed") {
          this.playAllTaggle = "closing";
          let queue = operateCameraList.map((item) =>
            item.startRealPlay({ iWndIndex: null })
          );
          await Promise.allSettled(queue);
          this.playAllTaggle = "played";
          szInfo = szInfo + "打开成功";
          return resolve(szInfo);
        }
      } catch (error) {
        szInfo = szInfo + "失败:" + error;
        return reject(szInfo);
      } finally {
        console.info(szInfo);
      }
    });
  }

  // 启用多边形绘制
  async enableDraw() {
    return new Promise(async (resolve, reject) => {
      let szInfo = "启用多边形绘制：";
      try {
        const res = await CommunicateWidthIframe.connect(this.ele, {
          connectType: "I_SetPlayModeType",
        });
        szInfo = szInfo + "成功";
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  // 关闭多边形绘制
  async disableDraw() {
    return new Promise(async (resolve, reject) => {
      let szInfo = "关闭多边形绘制：";
      try {
        const res = await CommunicateWidthIframe.connect(this.ele, {
          connectType: "I_SetSnapDrawMode",
        });
        szInfo = szInfo + "成功";
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async AddSnapPolygon(params) {
    return new Promise(async (resolve, reject) => {
      let szInfo = "开始形绘制：";
      try {
        const res = await CommunicateWidthIframe.connect(this.ele, {
          connectType: "AddSnapPolygon",
          params,
        });
        szInfo = szInfo + "成功";
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  // 获取形绘数据：
  async I_GetSnapPolygonInfo(params) {
    return new Promise(async (resolve, reject) => {
      let szInfo = "获取形绘数据：";
      try {
        const res = await CommunicateWidthIframe.connect(this.ele, {
          connectType: "I_GetSnapPolygonInfo",
          params,
        });
        szInfo = szInfo + "成功";
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  // 清空形绘数据：
  async I_ClearSnapInfo(params) {
    return new Promise(async (resolve, reject) => {
      let szInfo = "获取形绘数据：";
      try {
        const res = await CommunicateWidthIframe.connect(this.ele, {
          connectType: "I_ClearSnapInfo",
          params,
        });
        szInfo = szInfo + "成功";
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  // 清空所有
  async clear() {
    this.cameraList.map((item) => item.stopPlayAndClear());
    this.cameraList.length = 0;
    this.cameraListData.length = 0;
    // this.equipmentList = [];
  }
}

import CommunicateWidthIframe from "./communicate";
import { pending } from "./utils";
export default class Camera {
  recordStatus = "stoped"; // prccessing, recording, stoped
  playStatus = "stoped"; // prccessing, playing, stoped
  voiceTalkStatus = "stoped"; // prccessing, talking, stoped
  iPTZSpeed = 4;
  voiceTalkChannel = [];
  equipment = null;
  iWndIndex = null;

  constructor({ channel, equipment, data, ele }) {
    this.channel = channel;
    this.iStreamType = 2;
    this.bZeroChannel = false;
    this.equipment = equipment;
    this.id = `${this.equipment.ip}_${this.equipment.port}_${channel}`;
    this.data = data;
    this.ele = ele;
  }

  setIWndIndex(iWndIndex) {
    this.iWndIndex = iWndIndex;
  }

  startRealPlay({ iWndIndex = null }) {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${iWndIndex}) startRealPlay:`;
      try {
        try {
        if (
          ![null, undefined].includes(iWndIndex) &&
          iWndIndex != this.iWndIndex
        ) {
          if (this.iWndIndex !== null) {
            await this.stopPlay();
            await pending(1000);
          }
          this.iWndIndex = iWndIndex;
        }

        if (this.playStatus == "playing") {
          szInfo = szInfo + "已预览中";
          return reject(szInfo);
        }
        if (this.playStatus == "prccessing") {
          szInfo = szInfo + "加载中";
          return reject(szInfo);
        }
        this.playStatus = "prccessing";

        // 判断设备是否登录过
        if (this.equipment.loginStatus !== "succeed") {
          await this.equipment.asyncLogin();
        } else {
          // console.log('设备已经登录过')
        }
        await this.I_Stop(this.iWndIndex);
        await pending(500);
        await CommunicateWidthIframe.p_connect(this.equipment.ele, {
          connectType: "I_StartRealPlay",
          params: {
            ip: this.equipment.ip,
            iWndIndex: this.iWndIndex,
            iStreamType: this.iStreamType,
            iChannelID: this.channel,
            bZeroChannel: this.bZeroChannel,
          },
        });
        this.playStatus = "playing";
        szInfo = szInfo + "开始预览成功！";
        resolve(szInfo);
      } catch (error) {
        if (error.errorCode == 3001) {
          console.log(`${szInfo} '重新加载'`);
          this.playStatus = "stoped";
          const res = this.startRealPlay({ iWndIndex });
          resolve(res);
        } else {
          console.error();
          szInfo = szInfo + "开始预览失败！" + JSON.stringify(error);
          reject(szInfo);
        }
      } finally {
        console.log(szInfo);
      }
    });
  }

  // 检查播放状态
  I_Stop(iWndIndex) {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${iWndIndex}) I_Stop:`;
      try {
        const oWndInfo = await CommunicateWidthIframe.connect(
          this.equipment.ele,
          { connectType: "I_GetWindowStatus", params: { iWndIndex } }
        );
        if (oWndInfo == null) {
          szInfo = szInfo + "未在播放";
          return resolve(szInfo);
        }
        await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_Stop",
          params: { iWndIndex },
        });
        szInfo = szInfo + "停止播放成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "停止播失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async stopPlay() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) stopPlay:`;
      try {
        if (this.playStatus == "prccessing") {
          szInfo = szInfo + "加载中";
          return reject(szInfo);
        }
        this.playStatus == "processing";

        if (this.iWndIndex == null) {
          szInfo = szInfo + "未在播放";
          this.playStatus = "stoped";
          return resolve(szInfo);
        }

        await this.I_Stop(this.iWndIndex);
        this.playStatus = "stoped";
        szInfo = szInfo + "停止播放成功";
        return resolve(true);
      } catch (error) {
        szInfo = szInfo + "停止播失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async stopPlayAndClear() {
    return this.stopPlay().then((res) => {
      this.iWndIndex = null;
      return res;
    });
  }

  async startOrEndRecord() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) startRecord:`;
      if (this.recordStatus == "processing") {
        szInfo = szInfo + "录像中";
        reject(szInfo);
      }
      try {
        let res = null;
        if (this.recordStatus == "stoped") {
          this.recordStatus = "processing";
          res = await CommunicateWidthIframe.connect(this.equipment.ele, {
            connectType: "startRecord",
          });
          this.recordStatus = "recording";
          szInfo = szInfo + "开始录像成功";
        } else if (this.recordStatus == "recording") {
          this.recordStatus = "processing";
          res = await CommunicateWidthIframe.connect(this.equipment.ele, {
            connectType: "endRecord",
          });
          this.recordStatus = "stoped";
          szInfo = szInfo + "结束录像成功";
        }
        resolve(res);
      } catch (error) {
        this.recordStatus = "stoped";
        szInfo = szInfo + "开始录像失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async startOrEndPlay() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) startOrEndPlay:`;
      try {
        let res = null;
        if (this.playStatus == "stoped") {
          await this.startRealPlay({ iWndIndex: null });
        } else if (this.playStatus == "playing") {
          await this.stopPlay();
        }
        resolve(res);
      } catch (error) {
        console.log(error);
        szInfo = szInfo + "失败-" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async capturePicture() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) capturePicture:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_CapturePic",
          params: {
            filename: `${new Date().getTime()}`,
            options: { bDateDir: true },
          },
        });
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async PTZControl({ iPTZIndex, bStop = false, iPTZSpeed = 4 }) {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) PTZControl:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_PTZControl",
          params: { iPTZIndex, bStop, options: { iPTZSpeed: this.iPTZSpeed } },
        });
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async goPreset(iPresetID) {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) goPreset:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_GoPreset",
          params: { iPresetID },
        });
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async I_GetAudioInfo() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) I_GetAudioInfo:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_GetAudioInfo",
          params: { ip: this.equipment.ip },
        });
        console.log("I_GetAudioInfo >>>>", res);
        this.voiceTalkChannel = res;
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async startVoiceTalk(channel) {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) startVoiceTalk:`;
      if (this.voiceTalkStatus == "processing") {
        szInfo = szInfo + "启动对讲中";
        reject(szInfo);
      }
      try {
        let res = null;
        if (this.voiceTalkStatus == "stoped") {
          this.voiceTalkStatus = "processing";
          res = await CommunicateWidthIframe.connect(this.equipment.ele, {
            connectType: "startVoiceTalk",
            params: { ip: this.equipment.ip, channel: channel },
          });
          this.voiceTalkStatus = "talking";
          szInfo = szInfo + "开始对讲成功";
        }
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "开始对失败" + error;
        this.voiceTalkStatus == "stoped";
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async endVoiceTalk() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) endVoiceTalk:`;
      try {
        let res = null;
        if (this.voiceTalkStatus == "talking") {
          res = await CommunicateWidthIframe.connect(this.equipment.ele, {
            connectType: "endVoiceTalk",
          });
          szInfo = szInfo + "关闭对讲成功";
        }
        this.voiceTalkStatus = "stoped";
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "关闭对讲失败" + error;
        this.voiceTalkStatus == "stoped";
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }
}

import CommunicateWidthIframe from "./communicate";
import { pending } from "./utils";
import { Equipment } from "./Equipment";
import { HcCameraController } from "./HcCameraController";

export enum RecordStatus {
  prccessing = "prccessing",
  recording = "recording",
  stoped = "stoped",
};

export enum PlayStatus {
  prccessing = "prccessing",
  playing = "playing",
  stoped = "stoped",
};

export enum VoiceTalkStatus {
  prccessing = "prccessing",
  talking = "talking",
  stoped = "stoped",
};

export class Camera {
  recordStatus: RecordStatus = RecordStatus.stoped;
  playStatus: PlayStatus = PlayStatus.stoped;
  voiceTalkStatus: VoiceTalkStatus = VoiceTalkStatus.stoped;
  iPTZSpeed: number = 4;
  voiceTalkChannel: Array<any> = [];
  equipment: Equipment;
  iWndIndex: number | null = null;

  channel: string = '';
  iStreamType: number = 2;
  bZeroChannel: boolean = false;
  id: string = '';
  data: any;
  ele: string = '';
  ctrl?: HcCameraController;
  constructor({ channel, equipment, data, ele, ctrl, iWndIndex }: { channel: string, equipment: Equipment, data: any, ele: string, ctrl: HcCameraController, iWndIndex?: number | null }) {
    this.channel = channel;
    this.iStreamType = 2;
    this.bZeroChannel = false;
    this.equipment = equipment;
    this.id = `${this.equipment.ip}_${this.equipment.port}_${channel}`;
    this.data = data;
    this.ele = ele;
    this.ctrl = ctrl;

    if (iWndIndex) {
      this.iWndIndex = iWndIndex;
    }

  }

  startRealPlay() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) startRealPlay:`;
      try {
        if (this.playStatus == PlayStatus.playing) {
          szInfo = szInfo + "已预览中";
          return resolve(szInfo);
        }
        if (this.playStatus == PlayStatus.prccessing) {
          szInfo = szInfo + "加载中";
          return reject(szInfo);
        }
        this.playStatus = PlayStatus.prccessing;

        // 判断设备是否登录过
        if (this.equipment.loginStatus !== "succeed") {
          await this.equipment.asyncLogin();
        } else {
          // console.log('设备已经登录过')
        }
        await this.I_Stop();
        await pending(500);
        await CommunicateWidthIframe.p_connect(this.equipment.ele, {
          connectType: "I_StartRealPlay",
          params: {
            ip: this.equipment.ip,
            iStreamType: this.iStreamType,
            iChannelID: this.channel,
            bZeroChannel: this.bZeroChannel,
            iWndIndex: this.iWndIndex
          },
        });
        this.playStatus = PlayStatus.playing;
        szInfo = szInfo + "开始预览成功！";
        resolve(szInfo);
      } catch (error) {
        if (error.errorCode == 3001) {
          console.log(`${szInfo} '重新加载'`);
          this.playStatus = PlayStatus.stoped;
          const res = this.startRealPlay();
          resolve(res);
        } else {
          console.error();
          szInfo = szInfo + "开始预览失败！" + JSON.stringify(error);
          reject(szInfo);
        }
      } finally {
        console.log(szInfo);
      }
    });
  }

  // 检查播放状态
  I_Stop() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) I_Stop:`;
      try {
        const oWndInfo = await CommunicateWidthIframe.connect(
          this.equipment.ele,
          { connectType: "I_GetWindowStatus", params: { iWndIndex: this.iWndIndex } }
        );
        if (oWndInfo == null) {
          szInfo = szInfo + "未在播放";
          return resolve(szInfo);
        }
        await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_Stop",
          params: {
            iWndIndex: this.iWndIndex
          },
        });
        szInfo = szInfo + "停止播放成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "停止播失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async stopPlay() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) stopPlay:`;
      try {
        if (this.playStatus == PlayStatus.prccessing) {
          szInfo = szInfo + "加载中";
          return reject(szInfo);
        }
        this.playStatus = PlayStatus.prccessing;

        if (this.iWndIndex == null) {
          szInfo = szInfo + "未在播放";
          this.playStatus = PlayStatus.stoped
          return resolve(szInfo);
        }

        await this.I_Stop();
        this.playStatus = PlayStatus.stoped
        szInfo = szInfo + "停止播放成功";
        return resolve(true);
      } catch (error) {
        szInfo = szInfo + "停止播失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async stopPlayAndClear() {
    return this.stopPlay().then((res) => {
      this.iWndIndex = null;
      return res;
    });
  }

  async startOrEndRecord() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) startRecord:`;
      if (this.recordStatus == RecordStatus.prccessing) {
        szInfo = szInfo + "录像中";
        reject(szInfo);
      }
      try {
        let res = null;
        if (this.recordStatus == RecordStatus.stoped) {
          this.recordStatus = RecordStatus.prccessing;
          res = await CommunicateWidthIframe.connect(this.equipment.ele, {
            connectType: "startRecord",
          });
          this.recordStatus = RecordStatus.recording;
          szInfo = szInfo + "开始录像成功";
        } else if (this.recordStatus == RecordStatus.recording) {
          this.recordStatus = RecordStatus.prccessing;
          res = await CommunicateWidthIframe.connect(this.equipment.ele, {
            connectType: "endRecord",
          });
          this.recordStatus = RecordStatus.stoped;
          szInfo = szInfo + "结束录像成功";
        }
        resolve(res);
      } catch (error) {
        this.recordStatus = RecordStatus.stoped;
        szInfo = szInfo + "开始录像失败" + error;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async startOrEndPlay() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) startOrEndPlay:`;
      try {
        let res = null;
        if (this.playStatus == PlayStatus.stoped) {
          await this.startRealPlay();
        } else if (this.playStatus == PlayStatus.playing) {
          await this.stopPlay();
        }
        resolve(res);
      } catch (error) {
        console.log(error);
        szInfo = szInfo + "失败-" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async capturePicture() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) capturePicture:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_CapturePic",
          params: {
            filename: `${new Date().getTime()}`,
            options: { bDateDir: true },
          },
        });
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async PTZControl({ iPTZIndex, bStop = false, iPTZSpeed = 4 }) {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) PTZControl:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_PTZControl",
          params: { iPTZIndex, bStop, options: { iPTZSpeed: this.iPTZSpeed } },
        });
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async goPreset(iPresetID) {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) goPreset:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_GoPreset",
          params: { iPresetID },
        });
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async setPreset(iPresetID) {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) setPreset:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, { connectType: 'I_SetPreset', params: { iPresetID } })
        szInfo = szInfo + '成功'
        resolve(true)
      } catch (error) {
        szInfo = szInfo + '失败' + JSON.stringify(error)
        reject(szInfo)
      } finally {
        console.log(szInfo)
      }
    })
  }

  async I_GetAudioInfo() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) I_GetAudioInfo:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_GetAudioInfo",
          params: { ip: this.equipment.ip },
        });
        console.log("I_GetAudioInfo >>>>", res);
        this.voiceTalkChannel = res;
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async startVoiceTalk(channel) {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) startVoiceTalk:`;
      if (this.voiceTalkStatus == VoiceTalkStatus.prccessing) {
        szInfo = szInfo + "启动对讲中";
        reject(szInfo);
      }
      try {
        let res = null;
        if (this.voiceTalkStatus == VoiceTalkStatus.stoped) {
          this.voiceTalkStatus = VoiceTalkStatus.prccessing;
          res = await CommunicateWidthIframe.connect(this.equipment.ele, {
            connectType: "startVoiceTalk",
            params: { ip: this.equipment.ip, channel: channel },
          });
          this.voiceTalkStatus = VoiceTalkStatus.talking;
          szInfo = szInfo + "开始对讲成功";
        }
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "开始对失败" + error;
        this.voiceTalkStatus == VoiceTalkStatus.stoped;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async endVoiceTalk() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) endVoiceTalk:`;
      try {
        let res = null;
        if (this.voiceTalkStatus == VoiceTalkStatus.talking) {
          res = await CommunicateWidthIframe.connect(this.equipment.ele, {
            connectType: "endVoiceTalk",
          });
          szInfo = szInfo + "关闭对讲成功";
        }
        this.voiceTalkStatus = VoiceTalkStatus.stoped;
        resolve(res);
      } catch (error) {
        szInfo = szInfo + "关闭对讲失败" + error;
        this.voiceTalkStatus == VoiceTalkStatus.stoped;
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  startBackPlay({ szStartTime, szEndTime }: { szStartTime: string, szEndTime: string }) {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) startBackPlay:`;
      console.log('szInfo>>>', szInfo)
      try {
        if (this.playStatus == PlayStatus.playing) {
          szInfo = szInfo + "已预览中";
          return resolve(szInfo);
        }
        if (this.playStatus == PlayStatus.prccessing) {
          szInfo = szInfo + "加载中";
          return reject(szInfo);
        }
        this.playStatus = PlayStatus.prccessing;

        // 判断设备是否登录过
        if (this.equipment.loginStatus !== "succeed") {
          await this.equipment.asyncLogin();
        } else {
          // console.log('设备已经登录过')
        }
        await this.I_Stop();
        await pending(500);
        await CommunicateWidthIframe.p_connect(this.equipment.ele, {
          connectType: "I_StartPlayback",
          params: {
            ip: this.equipment.ip,
            options: {
              iStreamType: this.iStreamType,
              iChannelID: this.channel,
              szStartTime,
              szEndTime
            }
          },
        });
        this.playStatus = PlayStatus.playing;
        szInfo = szInfo + "成功";
        resolve(szInfo);
      } catch (error) {
        if (error.errorCode == 3001) {
          console.log(`${szInfo} '重新加载'`);
          this.playStatus = PlayStatus.stoped;
          const res = this.startBackPlay({ szStartTime, szEndTime });
          resolve(res);
        } else {
          console.error();
          szInfo = szInfo + "成功" + JSON.stringify(error);
          reject(szInfo);
        }
      } finally {
        console.log(szInfo);
      }
    });
  }

  async I_Pause() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) I_Pause:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_Pause",
          params: {},
        });
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async I_Resume() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) I_Resume:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_Resume",
          params: {},
        });
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async I_PlaySlow() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) I_PlaySlow:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_PlaySlow",
          params: {},
        });
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }

  async I_PlayFast() {
    return new Promise(async (resolve, reject) => {
      let szInfo = `camera (${this.equipment.ip} ${this.channel} ${this.iWndIndex}) I_PlayFast:`;
      try {
        const res = await CommunicateWidthIframe.connect(this.equipment.ele, {
          connectType: "I_PlayFast",
          params: {},
        });
        szInfo = szInfo + "成功";
        resolve(true);
      } catch (error) {
        szInfo = szInfo + "失败" + JSON.stringify(error);
        reject(szInfo);
      } finally {
        console.log(szInfo);
      }
    });
  }
}

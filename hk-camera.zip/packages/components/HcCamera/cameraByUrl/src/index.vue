<script lang="ts" setup>
import { reactive, watch, nextTick } from "vue";

const state = reactive({
  url: "",
});

const props = defineProps({
  cameraData: {
    type: Object,
    default: null,
    required: false,
  },
  ctrl: {
    type: Object,
    default: null,
    required: false,
  },
});

watch(
  () => props.cameraData,
  async (cameraData) => {
    if (!cameraData) return;
    state.url = "";
    nextTick(() => {
      const { data, ...cameraInfo } = cameraData;
      state.url = new URLSearchParams(cameraInfo).toString();
    });
  },
  { deep: true, immediate: true }
);
</script>

<template>
  <iframe
    v-if="state.url"
    class="windows"
    :src="`/hclib/v3.0/directlyPlay.html?${state.url}`"
    frameborder="0"
  />
</template>

<style lang="scss" scoped>
.windows {
  width: 100%;
  height: 100%;
}
</style>

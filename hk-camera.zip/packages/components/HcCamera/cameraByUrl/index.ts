import CameraByUrl from "./src/index.vue";

import { withInstall } from '../../withInstall';

const useCameraByUrl = withInstall(CameraByUrl);

export default useCameraByUrl;
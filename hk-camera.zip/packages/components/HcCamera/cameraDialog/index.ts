import CameraDialog from "./src/index.vue";

import { withInstall } from '../../withInstall'

const useCameraDialog = withInstall(CameraDialog)

export default useCameraDialog
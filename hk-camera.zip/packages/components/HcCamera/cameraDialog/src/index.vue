<script lang="ts" setup>
import { reactive, onBeforeUnmount } from "vue";
import { Close } from "@element-plus/icons-vue";
import CameraByUrl from "../../cameraByUrl/src/index.vue";

const state = reactive({
  visible: false,
  cameraData: null,
});

const open = async (cameraData) => {
  state.cameraData = cameraData;
  state.visible = true;
};

const handleClose = async () => {
  state.visible = false;
};

onBeforeUnmount(() => {
  handleClose();
});

defineExpose({
  open,
});
</script>

<template>
  <Teleport to="body">
    <div class="cameraDialog" ref="iframe_camera" v-if="state.visible">
      <div class="cameraDialog__inner">
        <div class="cameraDialog__container">
          <div class="cameraDialog__header">
            <div class="header__left"></div>
            <div class="header__right" @click="state.visible = false">
              <el-icon style="vertical-align: middle; color: #fff">
                <Close />
              </el-icon>
            </div>
          </div>
          <div class="cameraDialog__body">
            <CameraByUrl :cameraData="state.cameraData" />
          </div>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<style lang="scss" scoped>
.cameraDialog {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background-color: rgb(0 0 0 / 46%);
  z-index: 99999999999;
  &__inner {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
  }

  &__container {
    display: flex;
    flex-direction: column;
    width: 900px;
    height: 720px;
  }

  &__header,
  .header {
    height: 42px;
    background-color: #1765e3;
    display: flex;
    &__left {
      height: 42px;
      flex: 1;
    }
    &__right {
      width: 42px;
      height: 42px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }

  &__body {
    flex: 1;
    background-color: #0b2363;
    padding: 5px;
    .windows {
      width: 100%;
      height: 100%;
    }
  }
}
</style>

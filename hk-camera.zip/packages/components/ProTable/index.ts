import ProTable from './src/index.vue'
import { withInstall } from '../withInstall'
export * from './src/interface'

const useProTable = withInstall(ProTable)

export default useProTable
import SearchForm from './src/index.vue'
import { withInstall } from '../withInstall'

const useSearchForm = withInstall(SearchForm)
export { SearchForm }
export default useSearchForm
import Grid from './src/index.vue'
import GridItem from './src/components/GridItem.vue'
import { withInstall } from '../withInstall'

const useGrid = withInstall(Grid)
export { Grid, GridItem }
export default useGrid
 #!/bin/bash

set -e
echo '开始构建组件库'

# 获取脚本所在的目录
PROJECT_ROOT=$(pwd)
echo $PROJECT_ROOT
$PROJECT_ROOT/node_modules/.bin/tsx $PROJECT_ROOT/scripts/update-version.ts


# node scripts/update-version.cjs
vite build

echo '组件库构建完成，现在发布'

$npm_execpath publish --registry=http://nexus.shinforobot.com/repository/basic-platform-ui/